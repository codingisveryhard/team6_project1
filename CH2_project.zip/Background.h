#pragma once
#include <iostream>
#include "Utility.h"

using namespace std;


// 임시용 출력확인용
void title();

void gameInfo();


int menuDraw();
