#pragma once
#include <iostream>
#include <Windows.h>
#include <conio.h>

using namespace std;

int keyControl();
